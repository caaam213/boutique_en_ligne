
<footer class="bg-dark">
<h1 class="text-white text-center">A propos de nous </h1>
<p id="about" class="text-white">Nous sommes une jeune compagnie qui est éco-responsable. Nous voulons vous vendre des produits de qualité et fidéliser notre clientèle</p>
<article class="CONTACT">
                <h4 id="info" class="text-center">CONTACTEZ-NOUS</h4>

                <div class="row justify-content-center mx-auto">
                    <div class="col-5">
                        <h5 class="text-center">N° TELEPHONE</h2>
                        <p class="text-center">+33 094728658</p>
                        </div>
                    <div class="col-5">
                        <h5 class="text-center">EMAIL</h2>
                        <p class="text-center">hlc.support@gmail.com</p>
                    </div>
                    <p class="text-center fst-italic text-white">©HLC ~ 2022</p>
                </div>

</footer>
