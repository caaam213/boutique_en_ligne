<?php
    $title = "Choix de l'adresse";
    $style = array("delivery_addresses");
    require_once(VIEWS_PATH.'header.php');
?>
<body style="overflow-x: hidden;color:white !important;" class="bg-secondary">
<?php require_once(VIEWS_PATH.'navbar.php'); ?>
<div class="mt-4"></div>
<center><iframe src="https://giphy.com/embed/Ldr1AQ5yOWSEotaXij" width="300" height="300" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></center>
<p class="text-center display-3 mt-3">La commande a bien été finalisée</p>
<center><a class="bttn-slant bttn-lg bttn-danger text-decoration-none" href="index.php?action=home">Retour à l'accueil</a></center>